# hsr-puller-python
A gacha pulling system based on Honkai: Star Rail's gacha rates. Made in Python 3.
